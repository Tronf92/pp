#include <stdio.h>
#include <stdlib.h>
void hanoi(int n,char a,char b,char c) {
if (n==1) printf(" muta %c --> %c\n",a,b);
    else {
        hanoi(n-1,a,c,b);
        printf(" muta %c --> %c\n",a,b);
        hanoi(n-1,c,b,a);
    }
}
int main() {
int n;
char a='A',b='B',c='C';
printf("cate discuri? ");
scanf("%d",&n);
hanoi(n,a,b,c);
return 1;
}
