#include <stdio.h>
#include <stdlib.h>
long fibonacci(int n) {
	if (n==0) return 0;
	else if (n==1) return 1;
            else return (fibonacci(n-1)+fibonacci(n-2));
}
int main(){
    int n;
    printf("Introduceti un numar natural:");
    scanf("%d",&n);
    printf ("\n Valoarea fuctiei fibonacci(%d) este:%d",n,fibonacci(n));
    return 0;
}
